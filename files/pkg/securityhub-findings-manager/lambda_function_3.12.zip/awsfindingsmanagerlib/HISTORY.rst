.. :changelog:

History
-------


0.1.0 (26-04-2024)
------------------

* Initial release.


0.1.1 (19-06-2024)
------------------

* Fix s3 backend.


0.1.2 (19-06-2024)
------------------

* Bump dependencies.


1.0.0 (26-07-2024)
------------------

* Fix event handling.

.. :changelog:

History
-------


0.1.0 (26-04-2024)
------------------

* Initial release.


0.1.1 (19-06-2024)
------------------

* Fix s3 backend.


0.1.2 (19-06-2024)
------------------

* Bump dependencies.


1.0.0 (26-07-2024)
------------------

* Fix event handling.


1.0.1 (02-10-2024)
------------------

* Bump template python version to 3.11.


1.0.2 (04-10-2024)
------------------

* Fix development dependencies.


1.0.3 (04-10-2024)
------------------

* Bump twine to latest version to fix upload on pipeline.


1.0.4 (14-10-2024)
------------------

* Bump template python version to 3.12.
* Bugfixes.
